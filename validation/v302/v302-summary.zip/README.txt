三國大陸戰役 戰略糧倉 V3.0.2 驗收資料

先閱讀 docs/validation-results.md。data/simulation-manifest.json 記錄每局執行狀態。
observed 保存各局原始憑證。checks 保存測試及重跑。
SHA256SUMS.txt 可核對每個獨立檔案。
