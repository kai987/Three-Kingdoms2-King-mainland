三國大陸戰役 V3.0.2 验收包压缩版

直接用 macOS 或普通 ZIP 工具解压。报告和主要汇总 CSV 位于 docs/ 与 data/，
各局目录中的 monthly.csv、factions.csv、cities.csv 与 run.json 可直接读取。
所有原始观战、复跑、截图、源码和验证结果均保留。

部分大型 CSV、CSV.GZ 和 JSONL.GZ 以 .xz 保存。Python 3 的 lzma.open
可以直接读取其解码内容。表格也可以用支持 XZ 的 pandas 读取。

若要使用依赖旧文件名的分析脚本，可把本 ZIP 和 restore_original_layout.py
放在同一个目录，在该目录运行以下命令。第二个参数须为新的目录。

  python3 restore_original_layout.py three-kingdoms-strategic-granary-v302-validation-under-512MB.zip restored-v302

省略第二个参数可以只校验内容。恢复会为 .gz 文件重建压缩层，解码后的内容
逐字节一致。恢复目录里的 SHA256SUMS.txt 对应实际恢复出的文件字节。

本 ZIP 的 SHA256SUMS.txt 用于直接解压后的文件核验。repack/ 保存原包成员哈希、
编码映射和被重压流水的解码内容哈希。
