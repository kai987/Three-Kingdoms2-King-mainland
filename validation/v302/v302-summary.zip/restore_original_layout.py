"""Verify the compact V3.0.2 ZIP or restore its original analysis paths."""
import argparse
import gzip
from hashlib import sha256
import json
import lzma
from pathlib import Path, PurePosixPath
from tempfile import TemporaryDirectory
from zipfile import ZipFile

MANIFEST = "repack/original-member-map.json"
ORIGINAL_HASHES = "repack/original-SHA256SUMS.txt"
CHUNK = 1024 * 1024


def safe_name(name):
    parts = name.split("/")
    if "\\" in name or any(part in ("", ".", "..") for part in parts) or PurePosixPath(name).is_absolute():
        raise ValueError(f"Unsafe path: {name!r}")
    return name


def original_hashes(stream):
    return {safe_name(name): digest for digest, name in
            (line.split("  ", 1) for line in stream.decode("utf-8").splitlines())}


def copy_or_verify(reader, target=None, gzip_output=False):
    digest = sha256()
    size = 0

    def read_all(writer):
        nonlocal size
        while payload := reader.read(CHUNK):
            digest.update(payload)
            size += len(payload)
            if writer:
                writer.write(payload)

    if target is None:
        read_all(None)
    else:
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("xb") as handle:
            if gzip_output:
                with gzip.GzipFile(fileobj=handle, mode="wb", filename="", compresslevel=6, mtime=0) as writer:
                    read_all(writer)
            else:
                read_all(handle)
    return digest.hexdigest(), size


def restore(archive, output=None):
    original = original_hashes(archive.read(ORIGINAL_HASHES))
    mapping = {row["original"]: row for row in json.loads(archive.read(MANIFEST))["encoded_members"]}
    restored_hashes = {}
    for original_path, stored_digest in original.items():
        target = output / original_path if output else None
        encoded = mapping.get(original_path)
        if encoded:
            with archive.open(safe_name(encoded["stored"])) as member, lzma.LZMAFile(member) as reader:
                digest, size = copy_or_verify(reader, target, encoded["original_encoding"] == "gzip")
            expected = encoded["decoded_sha256"], encoded["decoded_bytes"]
            if (digest, size) != expected:
                raise ValueError(f"Decoded content differs from the original: {original_path}")
            if encoded["original_encoding"] == "gzip" and target is not None:
                with target.open("rb") as handle:
                    restored_hashes[original_path], _ = copy_or_verify(handle)
                continue
        else:
            with archive.open(original_path) as reader:
                digest, _ = copy_or_verify(reader, target)
            if digest != stored_digest:
                raise ValueError(f"Original content mismatch: {original_path}")
        restored_hashes[original_path] = digest

    if output is not None:
        (output / "SHA256SUMS.txt").write_text(
            "".join(f"{digest}  {name}\n" for name, digest in sorted(restored_hashes.items())), encoding="utf-8")
    return len(original), len(mapping)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    parser.add_argument("output", type=Path, nargs="?", help="New directory for the original analysis paths. Omit to verify.")
    opts = parser.parse_args()
    with ZipFile(opts.archive) as archive:
        if opts.output is None:
            count, converted = restore(archive)
        else:
            target = opts.output.resolve()
            if target.exists() or not target.parent.is_dir():
                parser.error("Output must be a new directory inside an existing parent.")
            with TemporaryDirectory(prefix=".tk2-restore-", dir=target.parent) as work:
                staged = Path(work) / "payload"
                staged.mkdir()
                count, converted = restore(archive, staged)
                if target.exists():
                    raise FileExistsError(target)
                staged.rename(target)
    print(f"Verified {count} original payload files, including {converted} XZ-encoded members.")


if __name__ == "__main__":
    main()
