# v302-rapid-smoke

短期观战及 29 剧本冒烟验证

原始 ZIP 为 `three-kingdoms-strategic-granary-v302-validation-under-512MB.zip`，SHA-256 为 `23d90ee1c1de9406ecca0ad96ee98ab5f5ef9fdc7662c70f7d9c67fb50711b96`。

原始成员沿用原目录路径及文件字节。还原流水的说明和 XZ 映射位于概要包。若同时解压多个包到同一目录，重复的汇总文件与运行清单的内容完全相同。

从解压根目录运行 `shasum -a 256 -c package-metadata/v302-rapid-smoke/SHA256SUMS.txt` 校验本包成员。如本包含有根目录的 SHA256SUMS.txt，它是原整包的校验记录。同名 ZIP 的外部 .sha256 文件用于校验压缩包。
