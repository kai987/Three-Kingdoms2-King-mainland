import base from '<WORKTREE>/tools/browser-tests/resupply.config.mjs';
const port=18977,url='http://127.0.0.1:'+port+'/';
export default {
 ...base, timeout:300000, outputDir:'/private/tmp/tk2-v23-visuals.1795771242413/resupply-browser-results',
 use:{...base.use,baseURL:url},
 webServer:{...base.webServer,command:'python3 -B tests/browser_resupply_fixture.py --port '+port, url,timeout:60_000},
 reporter:[['list'],['json',{outputFile:'/private/tmp/tk2-v23-visuals.1795771242413/resupply-browser-results.json'}]]
};
