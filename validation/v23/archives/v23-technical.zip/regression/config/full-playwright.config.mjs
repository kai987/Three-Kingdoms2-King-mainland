import base from '<WORKTREE>/tools/browser-tests/playwright.config.mjs';
const port=18975,url='http://127.0.0.1:'+port+'/Three-Kingdoms2-King-mainland/';
export default {
 ...base, outputDir:'/private/tmp/tk2-v23-visuals.1795771242413/full-browser-results', timeout:480000, retries:0,
 use:{...base.use,baseURL:url,video:'off'},
 webServer:{...base.webServer,url,timeout:60_000,
   env:{...base.webServer.env,TK2_STATIC_TEST_PORT:String(port)}},
 reporter:[['list'],['json',{outputFile:'/private/tmp/tk2-v23-visuals.1795771242413/full-browser-results.json'}]],
};
