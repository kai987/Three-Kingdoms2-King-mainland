# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: browser_soldier_ui.spec.mjs >> manual deployment places sequentially in native zones with zero-cost checkpoints and defender AI handoff
- Location: tests/browser_soldier_ui.spec.mjs:771:1

# Error details

```
Error: spawnSync python3 ETIMEDOUT
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - banner [ref=e2]:
    - generic [ref=e3]:
      - heading "三國·大陸戰役" [level=1] [ref=e4]
      - paragraph [ref=e5]: 184年2月上旬 · 選擇勢力
    - region [ref=e6]:
      - generic [ref=e7]:
        - heading "戰報" [level=2] [ref=e8]
        - button "重開戰役" [disabled] [ref=e9]
      - list [ref=e10]:
        - listitem [ref=e11]: 選擇勢力後開始。
    - navigation "進度與規則" [ref=e12]:
      - button "返回主選單" [disabled] [expanded] [ref=e13]
      - button "儲存進度" [disabled] [ref=e14]
      - button "讀取進度" [ref=e15] [cursor=pointer]
      - button "雲端存檔" [ref=e16] [cursor=pointer]
      - group [ref=e17]:
        - generic "更多 ▾" [ref=e18] [cursor=pointer]
        - option "繁體中文" [selected]
        - option "日本語"
  - main [ref=e19]:
    - generic [ref=e20]:
      - region "戰役地圖" [ref=e21]:
        - img "128城地圖，128城開放" [ref=e22]:
          - button "襄平，無主" [ref=e170] [cursor=pointer]
          - button "涿，地方漢郡（中立）" [ref=e174] [cursor=pointer]
          - button "晉陽，丁原" [ref=e178] [cursor=pointer]
          - button "臨淄，無主" [ref=e182] [cursor=pointer]
          - button "鄴，何進" [ref=e186] [cursor=pointer]
          - button "西河，無主" [ref=e190] [cursor=pointer]
          - button "姑臧，馬騰" [ref=e194] [cursor=pointer]
          - button "安定，董卓" [ref=e198] [cursor=pointer]
          - button "長安，何進" [ref=e202] [cursor=pointer]
          - button "金城，無主" [ref=e206] [cursor=pointer]
          - button "東海，無主" [ref=e210] [cursor=pointer]
          - button "昌邑，地方漢郡（中立）" [ref=e214] [cursor=pointer]
          - button "洛陽，何進" [ref=e218] [cursor=pointer]
          - button "章陵，無主" [ref=e222] [cursor=pointer]
          - button "許，張角" [ref=e226] [cursor=pointer]
          - button "秣陵，無主" [ref=e230] [cursor=pointer]
          - button "壽春，無主" [ref=e234] [cursor=pointer]
          - button "南昌，無主" [ref=e238] [cursor=pointer]
          - button "交趾，士燮" [ref=e242] [cursor=pointer]
          - button "鬱林，無主" [ref=e246] [cursor=pointer]
          - button "江夏，無主" [ref=e250] [cursor=pointer]
          - button "江陵，無主" [ref=e254] [cursor=pointer]
          - button "蒼梧，無主" [ref=e258] [cursor=pointer]
          - button "長沙，無主" [ref=e262] [cursor=pointer]
          - button "零陵，無主" [ref=e266] [cursor=pointer]
          - button "漢中，無主" [ref=e270] [cursor=pointer]
          - button "成都，無主" [ref=e274] [cursor=pointer]
          - button "江州，無主" [ref=e278] [cursor=pointer]
          - button "雲南，無主" [ref=e282] [cursor=pointer]
          - button "永昌，無主" [ref=e286] [cursor=pointer]
          - button "房陵，無主" [ref=e290] [cursor=pointer]
          - button "宛城，張角" [ref=e294] [cursor=pointer]
          - button "南皮，張角" [ref=e298] [cursor=pointer]
          - button "漢陽，無主" [ref=e302] [cursor=pointer]
          - button "廬江，無主" [ref=e306] [cursor=pointer]
          - button "桂陽，無主" [ref=e310] [cursor=pointer]
          - button "北海，無主" [ref=e314] [cursor=pointer]
          - button "濮陽，張角" [ref=e318] [cursor=pointer]
          - button "陳留，何進" [ref=e322] [cursor=pointer]
          - button "汝南，無主" [ref=e326] [cursor=pointer]
          - button "小沛，張角" [ref=e330] [cursor=pointer]
          - button "下邳，孫堅" [ref=e334] [cursor=pointer]
          - button "武都，無主" [ref=e338] [cursor=pointer]
          - button "魚復，無主" [ref=e342] [cursor=pointer]
          - button "吳，無主" [ref=e346] [cursor=pointer]
          - button "武陵，無主" [ref=e350] [cursor=pointer]
          - button "山陰，無主" [ref=e354] [cursor=pointer]
          - button "夷洲，島嶼地區（中立）" [ref=e358] [cursor=pointer]
          - button "樂浪，地方漢郡（中立）" [ref=e362] [cursor=pointer]
          - button "梓潼，無主" [ref=e366] [cursor=pointer]
          - button "雒城，無主" [ref=e370] [cursor=pointer]
          - button "綿虒，無主" [ref=e374] [cursor=pointer]
          - button "閬中，無主" [ref=e378] [cursor=pointer]
          - button "犍為，無主" [ref=e382] [cursor=pointer]
          - button "江陽，無主" [ref=e386] [cursor=pointer]
          - button "漢嘉，無主" [ref=e390] [cursor=pointer]
          - button "朱提，無主" [ref=e394] [cursor=pointer]
          - button "越巂，無主" [ref=e398] [cursor=pointer]
          - button "牂牁，無主" [ref=e402] [cursor=pointer]
          - button "味，無主" [ref=e406] [cursor=pointer]
          - button "宛溫，無主" [ref=e410] [cursor=pointer]
          - button "陰平，無主" [ref=e414] [cursor=pointer]
          - button "涪陵，無主" [ref=e418] [cursor=pointer]
          - button "鄱陽，無主" [ref=e422] [cursor=pointer]
          - button "廬陵，無主" [ref=e426] [cursor=pointer]
          - button "蘄春，無主" [ref=e430] [cursor=pointer]
          - button "臨賀，無主" [ref=e434] [cursor=pointer]
          - button "番禺，無主" [ref=e438] [cursor=pointer]
          - button "高涼，無主" [ref=e442] [cursor=pointer]
          - button "合浦，無主" [ref=e446] [cursor=pointer]
          - button "九真，無主" [ref=e450] [cursor=pointer]
          - button "日南，無主" [ref=e454] [cursor=pointer]
          - button "薊，劉焉" [ref=e458] [cursor=pointer]
          - button "漁陽，公孫瓚" [ref=e462] [cursor=pointer]
          - button "上谷，無主" [ref=e466] [cursor=pointer]
          - button "代，無主" [ref=e470] [cursor=pointer]
          - button "遼西，無主" [ref=e474] [cursor=pointer]
          - button "常山，無主" [ref=e478] [cursor=pointer]
          - button "中山，無主" [ref=e482] [cursor=pointer]
          - button "信都，無主" [ref=e486] [cursor=pointer]
          - button "平原，張角" [ref=e490] [cursor=pointer]
          - button "濟南，無主" [ref=e494] [cursor=pointer]
          - button "濟陰，無主" [ref=e498] [cursor=pointer]
          - button "東平，無主" [ref=e502] [cursor=pointer]
          - button "河內，無主" [ref=e506] [cursor=pointer]
          - button "河東，地方漢郡（中立）" [ref=e510] [cursor=pointer]
          - button "弘農，無主" [ref=e514] [cursor=pointer]
          - button "馮翊，無主" [ref=e518] [cursor=pointer]
          - button "扶風，無主" [ref=e522] [cursor=pointer]
          - button "隴西，無主" [ref=e526] [cursor=pointer]
          - button "上黨，無主" [ref=e530] [cursor=pointer]
          - button "襄陽，無主" [ref=e534] [cursor=pointer]
          - button "朱崖，島嶼地區（中立）" [ref=e538] [cursor=pointer]
          - button "西平，無主" [ref=e542] [cursor=pointer]
          - button "張掖，無主" [ref=e546] [cursor=pointer]
          - button "酒泉，無主" [ref=e550] [cursor=pointer]
          - button "敦煌，無主" [ref=e554] [cursor=pointer]
          - button "趙，無主" [ref=e558] [cursor=pointer]
          - button "鉅鹿，無主" [ref=e562] [cursor=pointer]
          - button "河間，無主" [ref=e566] [cursor=pointer]
          - button "甘陵，無主" [ref=e570] [cursor=pointer]
          - button "雁門，無主" [ref=e574] [cursor=pointer]
          - button "鄂，無主" [ref=e578] [cursor=pointer]
          - button "葭萌，無主" [ref=e582] [cursor=pointer]
          - button "涪，無主" [ref=e586] [cursor=pointer]
          - button "宕渠，無主" [ref=e590] [cursor=pointer]
          - button "南廣，無主" [ref=e594] [cursor=pointer]
          - button "合肥，無主" [ref=e598] [cursor=pointer]
          - button "廣陵，無主" [ref=e602] [cursor=pointer]
          - button "柴桑，無主" [ref=e606] [cursor=pointer]
          - button "西城，地方漢郡（中立）" [ref=e610] [cursor=pointer]
          - button "上庸，無主" [ref=e614] [cursor=pointer]
          - button "夷陵，無主" [ref=e618] [cursor=pointer]
          - button "柳城，烏桓" [ref=e622] [cursor=pointer]
          - button "朔方，何進" [ref=e626] [cursor=pointer]
          - button "五原，何進" [ref=e630] [cursor=pointer]
          - button "雲中，何進" [ref=e634] [cursor=pointer]
          - button "東萊，何進" [ref=e638] [cursor=pointer]
          - button "琅邪，何進" [ref=e642] [cursor=pointer]
          - button "泰山，何進" [ref=e646] [cursor=pointer]
          - button "玄菟，何進" [ref=e650] [cursor=pointer]
          - button "國內城，男武" [ref=e654] [cursor=pointer]
          - button "呂宋，可設城地點" [ref=e658] [cursor=pointer]
          - button "梁，何進" [ref=e661] [cursor=pointer]
          - button "彭城，何進" [ref=e665] [cursor=pointer]
          - button "魯，地方漢郡（中立）" [ref=e669] [cursor=pointer]
          - button "右北平，何進" [ref=e673] [cursor=pointer]
          - button "樂安，地方漢郡（中立）" [ref=e677] [cursor=pointer]
          - generic [aria-hidden] [ref=e681] [cursor=pointer]: 襄平
          - generic [aria-hidden] [ref=e682] [cursor=pointer]: 晉陽
          - generic [aria-hidden] [ref=e683] [cursor=pointer]: 臨淄
          - generic [aria-hidden] [ref=e684] [cursor=pointer]: 鄴
          - generic [aria-hidden] [ref=e685] [cursor=pointer]: 姑臧
          - generic [aria-hidden] [ref=e686] [cursor=pointer]: 長安
          - generic [aria-hidden] [ref=e687] [cursor=pointer]: 金城
          - generic [aria-hidden] [ref=e688] [cursor=pointer]: 昌邑
          - generic [aria-hidden] [ref=e689] [cursor=pointer]: 洛陽
          - generic [aria-hidden] [ref=e690] [cursor=pointer]: 許
          - generic [aria-hidden] [ref=e691] [cursor=pointer]: 秣陵
          - generic [aria-hidden] [ref=e692] [cursor=pointer]: 壽春
          - generic [aria-hidden] [ref=e693] [cursor=pointer]: 南昌
          - generic [aria-hidden] [ref=e694] [cursor=pointer]: 江陵
          - generic [aria-hidden] [ref=e695] [cursor=pointer]: 成都
          - generic [aria-hidden] [ref=e696] [cursor=pointer]: 江州
          - generic [aria-hidden] [ref=e697] [cursor=pointer]: 宛城
          - generic [aria-hidden] [ref=e698] [cursor=pointer]: 南皮
          - generic [aria-hidden] [ref=e699] [cursor=pointer]: 漢陽
          - generic [aria-hidden] [ref=e700] [cursor=pointer]: 濮陽
          - generic [aria-hidden] [ref=e701] [cursor=pointer]: 武都
          - generic [aria-hidden] [ref=e702] [cursor=pointer]: 吳
          - generic [aria-hidden] [ref=e703] [cursor=pointer]: 山陰
          - generic [aria-hidden] [ref=e704] [cursor=pointer]: 雒城
          - generic [aria-hidden] [ref=e705] [cursor=pointer]: 閬中
          - generic [aria-hidden] [ref=e706] [cursor=pointer]: 陰平
          - generic [aria-hidden] [ref=e707] [cursor=pointer]: 番禺
          - generic [aria-hidden] [ref=e708] [cursor=pointer]: 薊
          - generic [aria-hidden] [ref=e709] [cursor=pointer]: 信都
          - generic [aria-hidden] [ref=e710] [cursor=pointer]: 隴西
          - generic [aria-hidden] [ref=e711] [cursor=pointer]: 西平
          - generic [aria-hidden] [ref=e712] [cursor=pointer]: 張掖
          - generic [aria-hidden] [ref=e713] [cursor=pointer]: 酒泉
          - generic [aria-hidden] [ref=e714] [cursor=pointer]: 敦煌
          - generic [aria-hidden] [ref=e715] [cursor=pointer]: 趙
          - generic [aria-hidden] [ref=e716] [cursor=pointer]: 鉅鹿
          - generic [aria-hidden] [ref=e717] [cursor=pointer]: 河間
          - generic [aria-hidden] [ref=e718] [cursor=pointer]: 甘陵
          - generic [aria-hidden] [ref=e719] [cursor=pointer]: 雁門
          - generic [aria-hidden] [ref=e720] [cursor=pointer]: 鄂
          - generic [aria-hidden] [ref=e721] [cursor=pointer]: 葭萌
          - generic [aria-hidden] [ref=e722] [cursor=pointer]: 涪
          - generic [aria-hidden] [ref=e723] [cursor=pointer]: 宕渠
          - generic [aria-hidden] [ref=e724] [cursor=pointer]: 南廣
          - generic [aria-hidden] [ref=e725] [cursor=pointer]: 合肥
          - generic [aria-hidden] [ref=e726] [cursor=pointer]: 廣陵
          - generic [aria-hidden] [ref=e727] [cursor=pointer]: 柴桑
          - generic [aria-hidden] [ref=e728] [cursor=pointer]: 西城
          - generic [aria-hidden] [ref=e729] [cursor=pointer]: 上庸
          - generic [aria-hidden] [ref=e730] [cursor=pointer]: 夷陵
          - generic [aria-hidden] [ref=e731] [cursor=pointer]: 柳城
          - generic [aria-hidden] [ref=e732] [cursor=pointer]: 朔方
          - generic [aria-hidden] [ref=e733] [cursor=pointer]: 五原
          - generic [aria-hidden] [ref=e734] [cursor=pointer]: 雲中
          - generic [aria-hidden] [ref=e735] [cursor=pointer]: 東萊
          - generic [aria-hidden] [ref=e736] [cursor=pointer]: 琅邪
          - generic [aria-hidden] [ref=e737] [cursor=pointer]: 泰山
          - generic [aria-hidden] [ref=e738] [cursor=pointer]: 玄菟
          - generic [aria-hidden] [ref=e739] [cursor=pointer]: 國內城
          - generic [aria-hidden] [ref=e740] [cursor=pointer]: 呂宋
          - generic [aria-hidden] [ref=e741] [cursor=pointer]: 梁
          - generic [aria-hidden] [ref=e742] [cursor=pointer]: 彭城
          - generic [aria-hidden] [ref=e743] [cursor=pointer]: 魯
          - generic [aria-hidden] [ref=e744] [cursor=pointer]: 右北平
          - generic [aria-hidden] [ref=e745] [cursor=pointer]: 樂安
        - group "地圖縮放比例（1–4倍）" [ref=e746]:
          - button "縮小地圖" [disabled] [ref=e747]: −
          - status "地圖縮放比例（1–4倍）" [ref=e748]: 100%
          - button "放大地圖" [ref=e749] [cursor=pointer]: ＋
        - paragraph [ref=e750]: 拖動地圖；滾輪或雙指縮放，範圍1到4倍。
        - generic [ref=e751]:
          - group "地圖視角" [ref=e752]:
            - button "本城" [ref=e753] [cursor=pointer]
            - button "全圖" [pressed] [ref=e754] [cursor=pointer]
            - generic [ref=e755]:
              - text: 城池
              - combobox "選擇城池" [ref=e756]:
                - option "襄平 · 無主"
                - option "涿 · 地方漢郡（中立）"
                - option "晉陽 · 丁原"
                - option "臨淄 · 無主"
                - option "鄴 · 何進"
                - option "西河 · 無主"
                - option "姑臧 · 馬騰"
                - option "安定 · 董卓"
                - option "長安 · 何進"
                - option "金城 · 無主"
                - option "東海 · 無主"
                - option "昌邑 · 地方漢郡（中立）"
                - option "洛陽 · 何進" [selected]
                - option "章陵 · 無主"
                - option "許 · 張角"
                - option "秣陵 · 無主"
                - option "壽春 · 無主"
                - option "南昌 · 無主"
                - option "交趾 · 士燮"
                - option "鬱林 · 無主"
                - option "江夏 · 無主"
                - option "江陵 · 無主"
                - option "蒼梧 · 無主"
                - option "長沙 · 無主"
                - option "零陵 · 無主"
                - option "漢中 · 無主"
                - option "成都 · 無主"
                - option "江州 · 無主"
                - option "雲南 · 無主"
                - option "永昌 · 無主"
                - option "房陵 · 無主"
                - option "宛城 · 張角"
                - option "南皮 · 張角"
                - option "漢陽 · 無主"
                - option "廬江 · 無主"
                - option "桂陽 · 無主"
                - option "北海 · 無主"
                - option "濮陽 · 張角"
                - option "陳留 · 何進"
                - option "汝南 · 無主"
                - option "小沛 · 張角"
                - option "下邳 · 孫堅"
                - option "武都 · 無主"
                - option "魚復 · 無主"
                - option "吳 · 無主"
                - option "武陵 · 無主"
                - option "山陰 · 無主"
                - option "夷洲 · 島嶼地區（中立）"
                - option "樂浪 · 地方漢郡（中立）"
                - option "梓潼 · 無主"
                - option "雒城 · 無主"
                - option "綿虒 · 無主"
                - option "閬中 · 無主"
                - option "犍為 · 無主"
                - option "江陽 · 無主"
                - option "漢嘉 · 無主"
                - option "朱提 · 無主"
                - option "越巂 · 無主"
                - option "牂牁 · 無主"
                - option "味 · 無主"
                - option "宛溫 · 無主"
                - option "陰平 · 無主"
                - option "涪陵 · 無主"
                - option "鄱陽 · 無主"
                - option "廬陵 · 無主"
                - option "蘄春 · 無主"
                - option "臨賀 · 無主"
                - option "番禺 · 無主"
                - option "高涼 · 無主"
                - option "合浦 · 無主"
                - option "九真 · 無主"
                - option "日南 · 無主"
                - option "薊 · 劉焉"
                - option "漁陽 · 公孫瓚"
                - option "上谷 · 無主"
                - option "代 · 無主"
                - option "遼西 · 無主"
                - option "常山 · 無主"
                - option "中山 · 無主"
                - option "信都 · 無主"
                - option "平原 · 張角"
                - option "濟南 · 無主"
                - option "濟陰 · 無主"
                - option "東平 · 無主"
                - option "河內 · 無主"
                - option "河東 · 地方漢郡（中立）"
                - option "弘農 · 無主"
                - option "馮翊 · 無主"
                - option "扶風 · 無主"
                - option "隴西 · 無主"
                - option "上黨 · 無主"
                - option "襄陽 · 無主"
                - option "朱崖 · 島嶼地區（中立）"
                - option "西平 · 無主"
                - option "張掖 · 無主"
                - option "酒泉 · 無主"
                - option "敦煌 · 無主"
                - option "趙 · 無主"
                - option "鉅鹿 · 無主"
                - option "河間 · 無主"
                - option "甘陵 · 無主"
                - option "雁門 · 無主"
                - option "鄂 · 無主"
                - option "葭萌 · 無主"
                - option "涪 · 無主"
                - option "宕渠 · 無主"
                - option "南廣 · 無主"
                - option "合肥 · 無主"
                - option "廣陵 · 無主"
                - option "柴桑 · 無主"
                - option "西城 · 地方漢郡（中立）"
                - option "上庸 · 無主"
                - option "夷陵 · 無主"
                - option "柳城 · 烏桓"
                - option "朔方 · 何進"
                - option "五原 · 何進"
                - option "雲中 · 何進"
                - option "東萊 · 何進"
                - option "琅邪 · 何進"
                - option "泰山 · 何進"
                - option "玄菟 · 何進"
                - option "國內城 · 男武"
                - option "呂宋 · 可設城地點"
                - option "梁 · 何進"
                - option "彭城 · 何進"
                - option "魯 · 地方漢郡（中立）"
                - option "右北平 · 何進"
                - option "樂安 · 地方漢郡（中立）"
            - button "切換城名顯示" [ref=e757] [cursor=pointer]: 名：主
          - time:
            - text: 184年
            - generic: 2月上旬
      - complementary "目前操作" [ref=e758]:
        - heading "主菜單" [level=2] [ref=e760]
        - generic [ref=e761]:
          - generic [ref=e762]:
            - generic [ref=e763]:
              - text: 選擇劇本
              - combobox "選擇劇本" [active] [ref=e764]:
                - option "184年2月 · 黃巾之亂" [selected]
                - option "188年6月 · 漢朝搖搖欲墜 · DLC"
                - option "190年1月 · 反董卓聯盟"
                - option "191年10月 · 二袁的意圖"
                - option "194年6月 · 群雄割據"
                - option "196年6月 · 曹操得勢 · DLC"
                - option "198年3月 · 呂布討伐戰 · DLC"
                - option "200年1月 · 官渡之戰"
                - option "202年6月 · 河北爭亂 · DLC"
                - option "207年9月 · 三顧茅廬"
                - option "208年10月 · 赤壁之戰"
                - option "211年7月 · 潼關之戰 · DLC"
                - option "212年12月 · 入蜀爭奪戰"
                - option "215年8月 · 合淝之戰 · DLC"
                - option "217年7月 · 漢中爭奪戰"
                - option "219年7月 · 關羽包圍網"
                - option "221年7月 · 夷陵前夕"
                - option "225年7月 · 征伐南蠻 · DLC"
                - option "227年2月 · 出師表"
                - option "234年2月 · 秋風五丈原"
                - option "238年1月 · 征討遼東"
                - option "249年1月 · 正始之變"
                - option "263年5月 · 蜀漢滅亡"
                - option "197年7月 · 皇帝呂布"
                - option "201年5月 · 華北霸者・袁紹"
                - option "209年6月 · 志在千里"
                - option "210年11月 · 二分天下之計"
                - option "212年6月 · 錦馬超展翅高飛"
                - option "235年1月 · 越過秋風"
            - generic [ref=e765]:
              - text: 遊戲難度
              - combobox "遊戲難度" [ref=e766]:
                - option "簡單"
                - option "普通" [selected]
                - option "困難"
            - generic [ref=e767]:
              - generic [ref=e768]: 武將壽命
              - combobox "武將壽命" [ref=e769]:
                - option "史實" [selected]
                - option "無"
          - paragraph [ref=e770]: 選「無」時，武將不會因年齡自然死亡。
          - generic [ref=e771]:
            - checkbox "啟用冬季天氣（實驗）" [ref=e772]
            - generic [ref=e773]: 啟用冬季天氣（實驗）
          - generic [ref=e774]:
            - checkbox "啟用冬季氣候與農業 V2.3（實驗）" [ref=e775]
            - generic [ref=e776]: 啟用冬季氣候與農業 V2.3（實驗）
          - generic [ref=e777]:
            - checkbox "啟用季節預報 V2.3.1（實驗）" [disabled] [ref=e778]
            - generic [ref=e779]: 啟用季節預報 V2.3.1（實驗）
          - generic [ref=e780]:
            - checkbox "啟用江南異常寒潮（實驗）" [disabled] [ref=e781]
            - generic [ref=e782]: 啟用江南異常寒潮（實驗）
          - generic [ref=e783]:
            - checkbox "啟用運輸應急 V2.2.2（實驗）" [ref=e784]
            - generic [ref=e785]: 啟用運輸應急 V2.2.2（實驗）
          - generic [ref=e786]:
            - checkbox "啟用區域市場 V3.0.1（實驗）" [ref=e787]
            - generic [ref=e788]: 啟用區域市場 V3.0.1（實驗）
          - generic [ref=e789]:
            - checkbox "啟用 AI 自動商業貿易（實驗）" [disabled] [ref=e790]
            - generic [ref=e791]: 啟用 AI 自動商業貿易（實驗）
          - generic [ref=e792]:
            - checkbox "啟用戰略糧倉 V3.0.2（實驗）" [ref=e793]
            - generic [ref=e794]: 啟用戰略糧倉 V3.0.2（實驗）
          - generic [ref=e795]:
            - checkbox "使用 V3.0.2.1 候選調糧規則" [disabled] [ref=e796]
            - generic [ref=e797]: 使用 V3.0.2.1 候選調糧規則
          - generic [ref=e798]:
            - checkbox "啟用水陸運輸容量 V3.0.3（實驗）" [ref=e799]
            - generic [ref=e800]: 啟用水陸運輸容量 V3.0.3（實驗）
          - generic [ref=e801]:
            - checkbox "啟用城池中轉 V3.0.4（實驗）" [ref=e802]
            - generic [ref=e803]: 啟用城池中轉 V3.0.4（實驗）
          - generic [ref=e804]:
            - checkbox "啟用 AI 輸送統籌 V3.0.4.1（實驗）" [ref=e805]
            - generic [ref=e806]: 啟用 AI 輸送統籌 V3.0.4.1（實驗）
          - generic [ref=e807]:
            - checkbox "啟用 AI 輸送統籌 V3.0.4.1.1（實驗）" [ref=e808]
            - generic [ref=e809]: 啟用 AI 輸送統籌 V3.0.4.1.1（實驗）
          - generic [ref=e810]:
            - checkbox "啟用 AI 輸送統籌 V3.0.4.1.2（實驗，AI 過境補糧優先保障城內口糧）" [ref=e811]
            - generic [ref=e812]: 啟用 AI 輸送統籌 V3.0.4.1.2（實驗，AI 過境補糧優先保障城內口糧）
          - generic [ref=e813]:
            - checkbox "啟用 AI 主動調糧" [disabled] [ref=e814]
            - generic [ref=e815]: 啟用 AI 主動調糧
          - generic [ref=e816]:
            - checkbox "啟用冬季戰略儲備" [disabled] [ref=e817]
            - generic [ref=e818]: 啟用冬季戰略儲備
          - generic [ref=e819]:
            - checkbox "啟用單站中轉（實驗）" [disabled] [ref=e820]
            - generic [ref=e821]: 啟用單站中轉（實驗）
          - paragraph [ref=e822]: 共29篇 · 史實23／假想6；DLC按年代排列。
          - paragraph [ref=e823]: 184年2月 · 128城 · 每城99人開局在籍140人，在野164人。
          - generic [ref=e824]:
            - generic [ref=e825] [cursor=pointer]:
              - radio "何進 何進 · 洛陽 都市 14 · 金 17360 · 糧 602610 · 兵士 124000 · 預備兵 13243 · 現役 49人" [checked] [ref=e826]
              - generic [ref=e830]:
                - generic [ref=e831]:
                  - generic [ref=e832]: 何進
                  - generic [ref=e833]: 何進 · 洛陽
                - generic [ref=e834]:
                  - generic [ref=e835]: 都市 14
                  - text: ·
                  - generic [ref=e836]: 金 17360
                  - text: ·
                  - generic [ref=e837]: 糧 602610
                  - text: ·
                  - generic [ref=e838]:
                    - generic [ref=e839]: 兵士 124000
                    - text: ·
                    - generic [ref=e840]: 預備兵 13243
                  - text: ·
                  - generic [ref=e841]: 現役 49人
            - generic [ref=e842] [cursor=pointer]:
              - radio "張角 張角 · 平原 都市 6 · 金 10500 · 糧 384250 · 兵士 270000 · 預備兵 5937 · 現役 27人" [ref=e843]
              - generic [ref=e847]:
                - generic [ref=e848]:
                  - generic [ref=e849]: 張角
                  - generic [ref=e850]: 張角 · 平原
                - generic [ref=e851]:
                  - generic [ref=e852]: 都市 6
                  - text: ·
                  - generic [ref=e853]: 金 10500
                  - text: ·
                  - generic [ref=e854]: 糧 384250
                  - text: ·
                  - generic [ref=e855]:
                    - generic [ref=e856]: 兵士 270000
                    - text: ·
                    - generic [ref=e857]: 預備兵 5937
                  - text: ·
                  - generic [ref=e858]: 現役 27人
            - generic [ref=e859] [cursor=pointer]:
              - radio "孫堅 孫堅 · 下邳 都市 1 · 金 1200 · 糧 52500 · 兵士 14000 · 預備兵 573 · 現役 11人" [ref=e860]
              - generic [ref=e864]:
                - generic [ref=e865]:
                  - generic [ref=e866]: 孫堅
                  - generic [ref=e867]: 孫堅 · 下邳
                - generic [ref=e868]:
                  - generic [ref=e869]: 都市 1
                  - text: ·
                  - generic [ref=e870]: 金 1200
                  - text: ·
                  - generic [ref=e871]: 糧 52500
                  - text: ·
                  - generic [ref=e872]:
                    - generic [ref=e873]: 兵士 14000
                    - text: ·
                    - generic [ref=e874]: 預備兵 573
                  - text: ·
                  - generic [ref=e875]: 現役 11人
            - generic [ref=e876] [cursor=pointer]:
              - radio "董卓 董卓 · 安定 都市 1 · 金 1020 · 糧 30500 · 兵士 20000 · 預備兵 573 · 現役 14人" [ref=e877]
              - generic [ref=e881]:
                - generic [ref=e882]:
                  - generic [ref=e883]: 董卓
                  - generic [ref=e884]: 董卓 · 安定
                - generic [ref=e885]:
                  - generic [ref=e886]: 都市 1
                  - text: ·
                  - generic [ref=e887]: 金 1020
                  - text: ·
                  - generic [ref=e888]: 糧 30500
                  - text: ·
                  - generic [ref=e889]:
                    - generic [ref=e890]: 兵士 20000
                    - text: ·
                    - generic [ref=e891]: 預備兵 573
                  - text: ·
                  - generic [ref=e892]: 現役 14人
            - generic [ref=e893] [cursor=pointer]:
              - radio "公孫瓚 公孫瓚 · 漁陽 都市 1 · 金 1020 · 糧 33500 · 兵士 18000 · 預備兵 597 · 現役 10人" [ref=e894]
              - generic [ref=e898]:
                - generic [ref=e899]:
                  - generic [ref=e900]: 公孫瓚
                  - generic [ref=e901]: 公孫瓚 · 漁陽
                - generic [ref=e902]:
                  - generic [ref=e903]: 都市 1
                  - text: ·
                  - generic [ref=e904]: 金 1020
                  - text: ·
                  - generic [ref=e905]: 糧 33500
                  - text: ·
                  - generic [ref=e906]:
                    - generic [ref=e907]: 兵士 18000
                    - text: ·
                    - generic [ref=e908]: 預備兵 597
                  - text: ·
                  - generic [ref=e909]: 現役 10人
            - generic [ref=e910] [cursor=pointer]:
              - radio "馬騰 馬騰 · 姑臧 都市 1 · 金 1020 · 糧 30500 · 兵士 16000 · 預備兵 1397 · 現役 3人" [ref=e911]
              - generic [ref=e915]:
                - generic [ref=e916]:
                  - generic [ref=e917]: 馬騰
                  - generic [ref=e918]: 馬騰 · 姑臧
                - generic [ref=e919]:
                  - generic [ref=e920]: 都市 1
                  - text: ·
                  - generic [ref=e921]: 金 1020
                  - text: ·
                  - generic [ref=e922]: 糧 30500
                  - text: ·
                  - generic [ref=e923]:
                    - generic [ref=e924]: 兵士 16000
                    - text: ·
                    - generic [ref=e925]: 預備兵 1397
                  - text: ·
                  - generic [ref=e926]: 現役 3人
            - generic [ref=e927] [cursor=pointer]:
              - radio "劉焉 劉焉 · 薊 都市 1 · 金 1200 · 糧 41750 · 兵士 20000 · 預備兵 572 · 現役 8人" [ref=e928]
              - generic [ref=e932]:
                - generic [ref=e933]:
                  - generic [ref=e934]: 劉焉
                  - generic [ref=e935]: 劉焉 · 薊
                - generic [ref=e936]:
                  - generic [ref=e937]: 都市 1
                  - text: ·
                  - generic [ref=e938]: 金 1200
                  - text: ·
                  - generic [ref=e939]: 糧 41750
                  - text: ·
                  - generic [ref=e940]:
                    - generic [ref=e941]: 兵士 20000
                    - text: ·
                    - generic [ref=e942]: 預備兵 572
                  - text: ·
                  - generic [ref=e943]: 現役 8人
            - generic [ref=e944] [cursor=pointer]:
              - radio "丁原 丁原 · 晉陽 都市 1 · 金 1350 · 糧 27250 · 兵士 16000 · 預備兵 851 · 現役 7人" [ref=e945]
              - generic [ref=e949]:
                - generic [ref=e950]:
                  - generic [ref=e951]: 丁原
                  - generic [ref=e952]: 丁原 · 晉陽
                - generic [ref=e953]:
                  - generic [ref=e954]: 都市 1
                  - text: ·
                  - generic [ref=e955]: 金 1350
                  - text: ·
                  - generic [ref=e956]: 糧 27250
                  - text: ·
                  - generic [ref=e957]:
                    - generic [ref=e958]: 兵士 16000
                    - text: ·
                    - generic [ref=e959]: 預備兵 851
                  - text: ·
                  - generic [ref=e960]: 現役 7人
            - generic [ref=e961] [cursor=pointer]:
              - radio "士燮 士燮 · 交趾 都市 1 · 金 1100 · 糧 37500 · 兵士 8000 · 預備兵 723 · 現役 6人" [ref=e962]
              - generic [ref=e966]:
                - generic [ref=e967]:
                  - generic [ref=e968]: 士燮
                  - generic [ref=e969]: 士燮 · 交趾
                - generic [ref=e970]:
                  - generic [ref=e971]: 都市 1
                  - text: ·
                  - generic [ref=e972]: 金 1100
                  - text: ·
                  - generic [ref=e973]: 糧 37500
                  - text: ·
                  - generic [ref=e974]:
                    - generic [ref=e975]: 兵士 8000
                    - text: ·
                    - generic [ref=e976]: 預備兵 723
                  - text: ·
                  - generic [ref=e977]: 現役 6人
            - generic [ref=e978] [cursor=pointer]:
              - radio "高句麗 男武 · 國內城 都市 1 · 金 950 · 糧 51000 · 兵士 2865 · 預備兵 722 · 現役 3人" [ref=e979]
              - generic [ref=e983]:
                - generic [ref=e984]:
                  - generic [ref=e985]: 高句麗
                  - generic [ref=e986]: 男武 · 國內城
                - generic [ref=e987]:
                  - generic [ref=e988]: 都市 1
                  - text: ·
                  - generic [ref=e989]: 金 950
                  - text: ·
                  - generic [ref=e990]: 糧 51000
                  - text: ·
                  - generic [ref=e991]:
                    - generic [ref=e992]: 兵士 2865
                    - text: ·
                    - generic [ref=e993]: 預備兵 722
                  - text: ·
                  - generic [ref=e994]: 現役 3人
            - generic [ref=e995] [cursor=pointer]:
              - radio "烏桓 丘力居 · 柳城 都市 1 · 金 1060 · 糧 51000 · 兵士 4632 · 預備兵 1014 · 現役 2人" [ref=e996]
              - generic [ref=e1000]:
                - generic [ref=e1001]:
                  - generic [ref=e1002]: 烏桓
                  - generic [ref=e1003]: 丘力居 · 柳城
                - generic [ref=e1004]:
                  - generic [ref=e1005]: 都市 1
                  - text: ·
                  - generic [ref=e1006]: 金 1060
                  - text: ·
                  - generic [ref=e1007]: 糧 51000
                  - text: ·
                  - generic [ref=e1008]:
                    - generic [ref=e1009]: 兵士 4632
                    - text: ·
                    - generic [ref=e1010]: 預備兵 1014
                  - text: ·
                  - generic [ref=e1011]: 現役 2人
          - paragraph [ref=e1012]:
            - img "何進的肖像" [ref=e1016]
            - generic [ref=e1017]:
              - text: 何進 · 14座都市 · 根據地 洛陽。
              - generic [ref=e1018]: 金 17360
              - text: ·
              - generic [ref=e1019]: 糧 602610
              - text: ·
              - generic [ref=e1020]:
                - generic [ref=e1021]: 兵士 124000
                - text: ·
                - generic [ref=e1022]: 預備兵 13243
              - text: ·
              - generic [ref=e1023]: 現役 49人
              - text: 。地圖已預覽本劇本歸屬，開始後才建立新戰役。
          - paragraph [ref=e1024]: 觀戰時，各勢力由 AI 自動行動。
          - group [ref=e1025]:
            - generic "進階設定與劇本資料" [ref=e1026] [cursor=pointer]
        - generic [ref=e1027]:
          - button "開始戰役" [ref=e1028] [cursor=pointer]
          - button "開始觀戰" [ref=e1029] [cursor=pointer]
```

# Test source

```ts
  673 |  expect(recast.save.state.battle.extended.tactical.points.defenders).toBe(locked.save.state.battle.extended.tactical.points.defenders-6);
  674 |  await control(page,'attack');await idle(page);const contact=await save(page);
  675 |  expect(contact.state.battle.extended.siege).toBeTruthy();expect(contact.state.battle.extended.conditions.units[String(restricted.actor)].remaining).toBe(3);
  676 |  expect(contact.state.rng).toEqual(recast.save.state.rng);proof.push({kind:'restricted',count:3,actual_tactic:true,contact_started:true});
  677 | 
  678 |  await load(page,expiry.save,'controlled-phantom-expiry.json');
  679 |  await page.locator(`[data-actor="${expiry.actor}"]`).click();await expect(page.locator(`[data-actor="${expiry.actor}"] [data-phantom-count="1"]`)).toBeVisible();
  680 |  const beforeExpiry=await read(page,false);await control(page,'battle-wait');const expired=await animation(page);
  681 |  expect(expired.save.state.battle.round).toBe(beforeExpiry.save.state.battle.round+1);expect(expired.save.state.rng).toEqual(beforeExpiry.save.state.rng);
  682 |  expect(expired.save.state.battle.extended.conditions).toEqual({schema:'tk2-battle-conditions-v1',day:expired.save.state.battle.round,units:{}});
  683 |  expect(expired.view.catalog.battle_tactical.actors[String(expiry.actor)].reachable.length).toBeGreaterThan(0);
  684 |  await expect(page.locator(`[data-actor="${expiry.actor}"] [data-phantom-count]`)).toHaveCount(0);
  685 |  await load(page,expired.save,'phantom-expired-roundtrip.json');expect(await save(page)).toEqual(expired.save);
  686 |  proof.push({kind:'expiry',before:1,after:0,round:expired.save.state.battle.round,rng_unchanged:true});
  687 |  await attach(testInfo,'phantom-condition-proof',proof);expect(pageErrors.get(page)).toEqual([]);
  688 | });
  689 | 
  690 | test('chain applies independent connected water counts with bilingual movement-only locks and saved expiry',async({page},testInfo)=>{
  691 |  await opening(page);
  692 |  const [cast,restricted,expiry]=JSON.parse(execFileSync(process.env.PYTHON||'python3',['-B',new URL('./browser_chain_fixture.py',import.meta.url).pathname],{encoding:'utf8',maxBuffer:16*1024*1024,timeout:90_000})),proof=[];
  693 |  const restrictedCount=restricted.counts[restricted.targets.indexOf(String(restricted.target))];expect([4,5]).toContain(restrictedCount);
  694 |  await load(page,cast.save,'controlled-chain-cast.json');await page.locator(`[data-actor="${cast.actor}"]`).click();await page.locator(`[data-target="${cast.target}"]`).click();
  695 |  const before=await read(page,false);await control(page,'tactic');await page.locator('#tactic-choice').selectOption('10');
  696 |  const forecast=page.locator('#tactic-effect-preview .tactic-effect-forecast:visible');
  697 |  await expect(forecast).toContainText('3 支水上敵隊各自抽取計數 4–5');await expect(forecast).toContainText('陸地敵隊只傳遞連通');
  698 |  await page.locator('#dialog-language').selectOption('ja');await expect(forecast).toContainText('陸上の敵は接続を伝えるだけ');expect(await save(page)).toEqual(before.save);
  699 |  await page.locator('#confirm-tactic').click();const after=await animation(page,{withView:false});
  700 |  expect(after.save.state.rng.draws-before.save.state.rng.draws).toBe(4);
  701 |  expect(after.save.state.battle.extended.tactical.points.attackers).toBe(before.save.state.battle.extended.tactical.points.attackers-9);
  702 |  for(const [index,id]of cast.targets.entries()){
  703 |   expect(after.save.state.battle.extended.conditions.units[id]).toEqual({kind:'chain',remaining:cast.counts[index]});
  704 |   await expect(page.locator(`[data-target="${id}"] [data-chain-count="${cast.counts[index]}"]`)).toBeVisible();
  705 |  }
  706 |  expect(after.save.state.battle.extended.conditions.units[String(cast.bridge)]).toBeUndefined();
  707 |  expect(after.save.state.battle.extended.support).toEqual(before.save.state.battle.extended.support);
  708 |  expect(after.save.state.battle.attackers).toEqual(before.save.state.battle.attackers);expect(after.save.state.battle.defenders).toEqual(before.save.state.battle.defenders);
  709 |  const history=await openBattleHistoryEntry(page,after.save.state.extension.events.items.at(-1));
  710 |  await expect(page.locator('#event-description .event-facts')).toContainText('付与時カウント'+cast.counts.join('／'));await page.locator('#event-dialog [data-language-picker]').selectOption('zh-Hant');
  711 |  await expect(page.locator('#event-description .event-facts')).toContainText('3支水上敵隊');await expect(page.locator('#event-dialog .event-person img').first()).toBeVisible();
  712 |  await evidence(page,testInfo,'chain-independent-water-event-tc');await closeBattleHistoryEntry(history);expect(await save(page)).toEqual(after.save);
  713 |  proof.push({kind:'cast',targets:cast.targets,counts:cast.counts,bridge:cast.bridge,draws:4,event:after.save.state.extension.events.items.at(-1).details});
  714 |  await load(page,restricted.save,'controlled-chain-restricted.json');await page.locator(`[data-actor="${restricted.target}"]`).click();await page.locator(`[data-target="${restricted.actor}"]`).click();
  715 |  const locked=await read(page);await expect(page.locator(`[data-actor="${restricted.target}"] [data-chain-count="${restrictedCount}"]`)).toBeVisible();
  716 |  expect(locked.view.catalog.battle_tactical.actors[String(restricted.target)].reachable).toEqual([]);
  717 |  await expect(page.locator('#battle-move')).toBeDisabled();await expect(page.locator('#attack')).toBeEnabled();await expect(page.locator('#duel')).toBeEnabled();
  718 |  await locale(page,'ja');await expect(page.locator('.battle-move-reason')).toContainText('連環により移動できません');
  719 |  await page.locator(`[data-actor="${restricted.target}"]`).focus();await page.keyboard.press('ArrowRight');await page.keyboard.press('Enter');expect(await save(page)).toEqual(locked.save);
  720 |  await evidence(page,testInfo,'chain-locked-attack-enabled-ja');
  721 |  await control(page,'tactic');await page.locator('#tactic-choice').selectOption('0');await expect(page.locator('#confirm-tactic')).toBeEnabled();await page.locator('#confirm-tactic').click();const fire=await animation(page,{withView:false});
  722 |  expect(fire.save.state.battle.extended.conditions.units[String(restricted.target)]).toEqual({kind:'chain',remaining:restrictedCount});
  723 |  await control(page,'attack');await idle(page);const contact=await save(page);expect(contact.state.battle.extended.siege).toBeTruthy();expect(contact.state.battle.extended.conditions.units[String(restricted.target)]).toEqual({kind:'chain',remaining:restrictedCount});proof.push({kind:'restricted',attack:true,tactic:true,own_lock_preserved:true});
  724 |  await load(page,expiry.save,'controlled-chain-expiry.json');await expect(page.locator(`[data-target="${expiry.target}"] [data-chain-count="1"]`)).toBeVisible();
  725 |  const expiryBefore=await read(page,false);await control(page,'battle-wait');const expired=await animation(page,{withView:false});
  726 |  expect(expired.save.state.battle.round).toBe(expiryBefore.save.state.battle.round+1);expect(expired.save.state.rng).toEqual(expiryBefore.save.state.rng);expect(expired.save.state.battle.extended.conditions.units[String(expiry.target)]).toBeUndefined();
  727 |  await expect(page.locator(`[data-target="${expiry.target}"] [data-chain-count]`)).toHaveCount(0);
  728 |  await load(page,expired.save,'chain-expired-roundtrip.json');expect(await save(page)).toEqual(expired.save);proof.push({kind:'expiry',rng_unchanged:true,round:expired.save.state.battle.round});
  729 |  await attach(testInfo,'chain-condition-proof',proof);expect(pageErrors.get(page)).toEqual([]);
  730 | });
  731 | 
  732 | test('qimen targets enemies with daily losses and experience, bilingual receipts and exact zero-troop expiry',async({page},testInfo)=>{
  733 |  await opening(page);
  734 |  const [cast,restricted,daily,expiry]=JSON.parse(execFileSync(process.env.PYTHON||'python3',['-B',new URL('./browser_qimen_fixture.py',import.meta.url).pathname],{encoding:'utf8',maxBuffer:16*1024*1024,timeout:90_000})),proof=[];
  735 |  // The new spatial success gate selects a different ordinary fixture seed.
  736 |  // Preserve the actual post-cast reference and every RNG/loss assertion,
  737 |  // rather than couple presentation checks to the old seed's duration.
  738 |  const castCount=restricted.count;expect(castCount).toBeGreaterThanOrEqual(6);expect(castCount).toBeLessThanOrEqual(9);
  739 |  await load(page,cast.save,'controlled-qimen-cast.json');await page.locator(`[data-actor="${cast.actor}"]`).click();await page.locator(`[data-target="${cast.target}"]`).click();
  740 |  const before=await read(page,false);await control(page,'tactic');await page.locator('#tactic-choice').selectOption('15');
  741 |  const forecast=page.locator('#tactic-effect-preview .tactic-effect-forecast:visible');await expect(forecast).toContainText('最後一次也損兵');await page.locator('#dialog-language').selectOption('ja');await expect(forecast).toContainText('自軍の盾ではなく');expect(await save(page)).toEqual(before.save);
  742 |  await page.locator('#confirm-tactic').click();const castResult=await animation(page,{withView:false});
  743 |  expect(castResult.save.state.rng.draws-before.save.state.rng.draws).toBe(2);expect(castResult.save.state.battle.extended.tactical.points.attackers).toBe(before.save.state.battle.extended.tactical.points.attackers-10);
  744 |  expect(castResult.save.state.battle.extended.conditions.units[String(cast.target)]).toEqual({kind:'qimen',remaining:castCount});
  745 |  expect(castResult.save.state.battle.extended.support).toEqual(before.save.state.battle.extended.support);expect(castResult.save.state.battle.attackers).toEqual(before.save.state.battle.attackers);expect(castResult.save.state.battle.defenders).toEqual(before.save.state.battle.defenders);
  746 |  await expect(page.locator(`[data-target="${cast.target}"] [data-qimen-count="${castCount}"]`)).toBeVisible();proof.push({kind:'cast',draws:2,count:castCount,guard_created:false});
  747 |  await load(page,restricted.save,'controlled-qimen-restricted.json');await page.locator(`[data-actor="${restricted.locked_actor}"]`).click();await page.locator(`[data-target="${restricted.enemy}"]`).click();const locked=await read(page);
  748 |  await expect(page.locator('#battle-move')).toBeDisabled();await expect(page.locator('#attack')).toBeEnabled();await expect(page.locator('#duel')).toBeEnabled();expect(locked.view.catalog.battle_tactical.actors[String(restricted.locked_actor)].reachable).toEqual([]);
  749 |  await locale(page,'ja');await expect(page.locator('.battle-move-reason')).toContainText('奇門遁甲により移動できません');await page.locator(`[data-actor="${restricted.locked_actor}"]`).focus();await page.keyboard.press('ArrowRight');await page.keyboard.press('Enter');expect(await save(page)).toEqual(locked.save);await evidence(page,testInfo,'qimen-enemy-lock-no-self-shield-ja');
  750 |  await control(page,'tactic');await page.locator('#tactic-choice').selectOption('0');await page.locator('#confirm-tactic').click();const fire=await animation(page,{withView:false});expect(fire.save.state.battle.extended.conditions.units[String(restricted.locked_actor)].remaining).toBe(castCount);
  751 |  await control(page,'attack');await idle(page);expect((await save(page)).state.battle.extended.siege).toBeTruthy();proof.push({kind:'restricted',attack:true,tactic:true,own_counter_preserved:true});
  752 |  for(const row of[daily,expiry]){
  753 |   await load(page,row.save,'controlled-qimen-'+row.kind+'.json');const prior=await read(page,false);await control(page,'battle-wait');const result=await animation(page,{withView:false}),expected=row.expected_daily;
  754 |   expect(result.save.state.rng).toEqual(expected.rng);expect(result.save.state.battle.round).toBe(expected.round);expect(result.save.state.officers[String(row.actor)].experience).toBe(expected.experience);expect(result.save.state.officers[String(row.actor)].tier).toBe(expected.tier);
  755 |   expect(result.save.state.officers[String(row.actor)].profile).toEqual(prior.save.state.officers[String(row.actor)].profile);expect(result.save.state.soldiers).toEqual(prior.save.state.soldiers);
  756 |   const receipt=result.save.state.extension.events.items.at(-1).details;expect(receipt).toEqual({tactic:15,success:true,condition:'qimen',qimen_phase:'daily',qimen_ticks:expected.rows,experience_id:String(row.actor),experience_gain:expected.experience_gain});
  757 |   expect(result.save.state.battle.extended.conditions.units[String(row.target)]).toEqual(expected.count?{kind:'qimen',remaining:expected.count}:undefined);
  758 |   expect(result.save.state.battle.extended.conditions.high_order).toEqual(prior.save.state.battle.extended.conditions.high_order);
  759 |   if(row.kind==='daily'){
  760 |    const history=await openBattleHistoryEntry(page,result.save.state.extension.events.items.at(-1));
  761 |    await expect(page.locator('#event-title')).toContainText('奇門の日界効果');await expect(page.locator('#event-description .event-facts')).toContainText('損兵合計'+expected.rows.reduce((sum,tick)=>sum+tick.loss,0));
  762 |    await page.locator('#event-dialog [data-language-picker]').selectOption('zh-Hant');await expect(page.locator('#event-title')).toContainText('奇門日界效果');await expect(page.locator('#event-description .event-facts')).toContainText(expected.experience_gain?'增加經驗'+expected.experience_gain:'合計損兵');await expect(page.locator('#event-dialog .event-person img').first()).toBeVisible();await evidence(page,testInfo,'qimen-daily-committed-loss-and-xp-tc');await closeBattleHistoryEntry(history);expect(await save(page)).toEqual(result.save);
  763 |   }else{
  764 |    expect(prior.save.state.battle.defenders.find(u=>u.id===row.target).troops).toBe(0);expect(result.save.state.rng.draws-prior.save.state.rng.draws).toBe(1);await expect(page.locator(`[data-target="${row.target}"] [data-qimen-count]`)).toHaveCount(0);
  765 |   }
  766 |   await load(page,result.save,'qimen-'+row.kind+'-roundtrip.json');expect(await save(page)).toEqual(result.save);proof.push({kind:row.kind,rows:receipt.qimen_ticks,experience_gain:receipt.experience_gain,round:expected.round});
  767 |  }
  768 |  await attach(testInfo,'qimen-condition-proof',proof);expect(pageErrors.get(page)).toEqual([]);
  769 | });
  770 | 
  771 | test('manual deployment places sequentially in native zones with zero-cost checkpoints and defender AI handoff',async({page},testInfo)=>{
  772 |  await opening(page);
> 773 |  const [attacker,defender,last]=JSON.parse(execFileSync(process.env.PYTHON||'python3',['-B',new URL('./browser_manual_deployment_fixture.py',import.meta.url).pathname],{encoding:'utf8',maxBuffer:16*1024*1024,timeout:90_000})),proof=[];
      |                                            ^ Error: spawnSync python3 ETIMEDOUT
  774 |  const domain=value=>{const state=structuredClone(value.state);delete state.battle.extended.placement;delete state.battle.extended.tactical.positions;return state;};
  775 |  await load(page,attacker.save,'real-arrival-attacker-placement.json');const before=await read(page);
  776 |  await expect(page.locator('[data-placement-progress]')).toHaveAttribute('data-placement-progress','0');await expect(page.locator('[data-placement-total]')).toHaveAttribute('data-placement-total','3');
  777 |  await expect(page.locator('#attack')).toHaveCount(0);await expect(page.locator('#battle-wait')).toHaveCount(0);expect(before.view.catalog.battle_tactical.can_end).toBe(false);
  778 |  expect(Object.keys(before.save.state.battle.extended.tactical.positions).sort()).toEqual(attacker.position_ids);expect(Object.values(before.view.catalog.battle_tactical.actors).every(a=>!a.can_act)).toBe(true);
  779 |  await cell(page,attacker.keyboard_point,testInfo.project.name.startsWith('touch'));await idle(page);expect(await save(page)).toEqual(before.save,'Unconfirmed pointer preview is not a saved move');
  780 |  const canvas=page.locator('[data-battle-canvas]');await canvas.focus();await page.keyboard.press('b');await page.keyboard.press('Escape');await page.keyboard.press('Shift');expect(await save(page)).toEqual(before.save);
  781 |  await cell(page,attacker.future_default,testInfo.project.name.startsWith('touch'));await evidence(page,testInfo,'manual-placement-future-default-preview-tc');expect(await save(page)).toEqual(before.save);
  782 |  // Real native Enter default actions are exercised while the key remains
  783 |  // held; autorepeat must never confirm the next officer automatically.
  784 |  await page.locator('#battle-place-confirm').focus();await page.keyboard.down('Enter');await idle(page);await expect(page.locator('[data-placement-progress]')).toHaveAttribute('data-placement-progress','1');const first=await read(page);
  785 |  expect(first.save.state.battle.extended.tactical.positions[String(attacker.actor)]).toEqual(attacker.future_default);
  786 |  expect(first.view.catalog.battle_tactical.placement.actor).toBe(attacker.expected_next.actor);expect(first.save.state.battle.extended.tactical.positions[String(attacker.expected_next.actor)]).toEqual(attacker.expected_next.default_point);
  787 |  expect(Object.keys(first.save.state.battle.extended.tactical.positions).sort()).toEqual(attacker.expected_next.position_ids);expect(domain(first.save)).toEqual(domain(before.save));
  788 |  await page.keyboard.down('Enter');await page.waitForTimeout(250);await idle(page);expect(await save(page)).toEqual(first.save,'Held Enter must not confirm a second officer');await page.keyboard.up('Enter');
  789 |  const compactChecksum=await page.evaluate(async()=>(await (await fetch('/api/save?compact=1')).json()).checksum);
  790 |  await expect.poll(()=>page.evaluate(checksum=>{const raw=localStorage.getItem('three-kingdoms-autosaves-v1');if(!raw)return false;const rows=JSON.parse(raw);return rows.items?.some(row=>JSON.parse(row.raw).checksum===checksum)||false;},compactChecksum)).toBe(true);
  791 |  await load(page,first.save,'confirmed-placement-checkpoint.json');expect(await save(page)).toEqual(first.save);await expect(page.locator('[data-placement-progress]')).toHaveAttribute('data-placement-progress','1');
  792 |  await locale(page,'ja');await expect(page.locator('#battle-place-confirm')).toContainText('この位置で確定');await expect(page.locator('#inspector')).toContainText('未確定の配置プレビューは保存しません');
  793 |  for(let i=0;i<2;i++){await control(page,'battle-place-confirm');await idle(page);}
  794 |  const ready=await read(page);expect(ready.save.state.battle.extended.placement.confirmed).toBe(3);expect(ready.view.catalog.battle_tactical.placement.pending).toBe(false);expect(domain(ready.save)).toEqual(domain(before.save));await expect(page.locator('#battle-place-confirm')).toHaveCount(0);await expect(page.locator('#battle-wait')).toBeEnabled();
  795 |  proof.push({kind:'attacker',future_does_not_occupy:true,next_default:first.save.state.battle.extended.tactical.positions[String(attacker.expected_next.actor)],resource_domain_unchanged:true,autosave:true});
  796 |  await load(page,defender.save,'real-arrival-defender-placement.json');const defenseBefore=await read(page,false);await expect(page.locator('[data-placement-total]')).toHaveAttribute('data-placement-total','10');
  797 |  await expect(page.locator('#stage')).toContainText('相手は武力と陣型に応じて配置済み');await cell(page,defender.terrain_cells['3'],testInfo.project.name.startsWith('touch'));await control(page,'battle-place-confirm');await idle(page);const water=await read(page,false);
  798 |  expect(water.save.state.battle.extended.tactical.positions[String(defender.actor)]).toEqual(defender.terrain_cells['3']);expect(domain(water.save)).toEqual(domain(defenseBefore.save));await evidence(page,testInfo,'manual-defender-commander-water-ja');proof.push({kind:'defender',commander_left_camp:true,water_legal:true,ai_has_not_acted:true});
  799 |  await load(page,last.save,'real-defender-last-placement.json');await expect(page.locator('[data-placement-progress]')).toHaveAttribute('data-placement-progress','9');const lastBefore=await read(page,false);await control(page,'battle-place-confirm');const started=await animation(page,{withView:false});
  800 |  expect(started.save.state.battle.extended.placement.confirmed).toBe(10);expect(started.save.state.battle.round).toBe(1);expect(started.save.state.battle.extended.supply.days).toBe(0);expect(started.save.state.battle.extended.tactical.side).toBe('defenders');expect(started.save.state.battle.extended.tactical.passed.attackers).toBe(true);expect(started.save.state.battle.extended.tactical.points.attackers).toBeLessThan(lastBefore.save.state.battle.extended.tactical.points.attackers);
  801 |  await expect(page.locator('#battle-place-confirm')).toHaveCount(0);await expect(page.locator('#battle-wait')).toBeEnabled();await load(page,started.save,'completed-placement-ready-battle.json');expect(await save(page)).toEqual(started.save);proof.push({kind:'defender_last',first_attacker_ai_ran:true,round:1,food_days:0});
  802 |  await attach(testInfo,'manual-deployment-proof',proof);expect(pageErrors.get(page)).toEqual([]);
  803 | });
  804 | 
  805 | test('native AI deployment keeps commanders and grouped martial order while sharing legal cells and preserving legacy saves',async({page},testInfo)=>{
  806 |  await opening(page);
  807 |  const rows=JSON.parse(execFileSync(process.env.PYTHON||'python3',['-B',new URL('./browser_ai_deployment_fixture.py',import.meta.url).pathname],{encoding:'utf8',maxBuffer:16*1024*1024,timeout:90_000})),proof=[];
  808 |  // Opening troop allocation changes which defenders make the ten-unit garrison.
  809 |  const expectedOrders={defenders:['829','99','504','714','121','980','13','379','37','464'],attackers:['50','203','119']};
  810 |  const domain=value=>{const state=structuredClone(value.state);delete state.battle.extended.placement;delete state.battle.extended.tactical.positions;return state;};
  811 |  for(const row of rows){
  812 |   await load(page,row.save,'real-native-ai-'+row.side+'.json');const before=await read(page),board=before.view.catalog.battle_tactical,plan=board.auto_deployment.sides[row.side];
  813 |   expect(plan.order).toEqual(expectedOrders[row.side]);expect(plan.groups).toEqual(row.groups);expect(plan.binding).toEqual(row.binding);expect(plan.profile).toBe(row.profile);
  814 |   expect(row.order[0]).toBe(String(before.save.state.battle[row.side][0].id));
  815 |   for(const id of row.order)expect(before.save.state.battle.extended.tactical.positions[id]).toEqual(row.expected[id]);
  816 |   await expect(page.locator('[data-ai-deployment]')).toHaveAttribute('data-ai-deployment','strategy');
  817 |   await locale(page,'zh-Hant');await expect(page.locator('[data-ai-deployment]')).toContainText('依武力與陣型');expect(await save(page)).toEqual(before.save);
  818 |   if(row.side==='defenders')await evidence(page,testInfo,'ai-grouped-defender-native-tc');
  819 |   await locale(page,'ja');await expect(page.locator('[data-ai-deployment]')).toContainText('武力と陣型');expect(await save(page)).toEqual(before.save);
  820 |   if(row.side==='attackers')await evidence(page,testInfo,'ai-grouped-attacker-native-ja');
  821 |   await control(page,'battle-place-confirm');await idle(page);const after=await read(page,false);
  822 |   expect(domain(after.save)).toEqual(domain(before.save));expect(after.save.state.battle.extended.auto_deployment).toEqual(before.save.state.battle.extended.auto_deployment);
  823 |   for(const id of row.order)expect(after.save.state.battle.extended.tactical.positions[id]).toEqual(row.expected[id]);
  824 |   await load(page,after.save,'partial-manual-with-frozen-ai.json');expect(await save(page)).toEqual(after.save);
  825 |   proof.push({side:row.side,profile:row.profile,order:plan.order,groups:plan.groups,positions:row.expected,resources_unchanged:true,roundtrip:true});
  826 |  }
  827 |  const legacy=rows[0].legacy;await load(page,legacy,'controlled-previous-ordered-defaults.json');const previous=await read(page);
  828 |  expect(previous.view.catalog.battle_tactical.auto_deployment).toBeNull();await expect(page.locator('[data-ai-deployment]')).toHaveAttribute('data-ai-deployment','legacy');
  829 |  expect(await save(page)).toEqual(legacy);await control(page,'battle-place-confirm');await idle(page);const continued=await read(page,false);
  830 |  expect(continued.save.state.battle.extended.auto_deployment).toBeUndefined();
  831 |  for(const unit of legacy.state.battle.defenders)expect(continued.save.state.battle.extended.tactical.positions[String(unit.id)]).toEqual(legacy.state.battle.extended.tactical.positions[String(unit.id)]);
  832 |  expect(domain(continued.save)).toEqual(domain(legacy));proof.push({kind:'controlled_legacy_pending',not_retrofitted:true});
  833 |  await attach(testInfo,'ai-deployment-proof',proof);expect(pageErrors.get(page)).toEqual([]);
  834 | });
  835 | 
  836 | test('general tactic forecasts share native distance and tier rules without drawing results',async({page},testInfo)=>{
  837 |  await opening(page);
  838 |  const rows=JSON.parse(execFileSync(process.env.PYTHON||'python3',['-B',new URL('./browser_general_tactic_fixture.py',import.meta.url).pathname],{encoding:'utf8',maxBuffer:16*1024*1024,timeout:90_000})),proof=[];
  839 |  for(const row of rows){
  840 |   await load(page,row.save,'controlled-general-distance-'+row.distance+'.json');await page.locator(`[data-actor="${row.actor}"]`).click();await page.locator(`[data-target="${row.target}"]`).click();
  841 |   const before=await read(page),quotes=before.view.catalog.battle_tactical.actors[String(row.actor)].tactic_previews;
  842 |   expect(quotes['2'][String(row.target)]).toEqual(row.preview);
  843 |   await control(page,'tactic');const forecast=page.locator('#tactic-effect-preview .tactic-effect-forecast:visible');
  844 |   for(const tid of ['0','2']){
  845 |    await page.locator('#tactic-choice').selectOption(tid);
  846 |    await expect(forecast).toHaveAttribute('data-tactic-success',String(row.percent));
  847 |    for(const language of ['zh-Hant','ja']){
  848 |     await page.locator('#dialog-language').selectOption(language);
  849 |     await expect(forecast).toContainText(language==='ja'?'プレイヤー／AI共通':'玩家／AI共用');
  850 |     await expect(forecast).toContainText(language==='ja'?'経験等級':'經驗等級');
  851 |     if(tid==='0')await expect(forecast).toContainText(language==='ja'?`距離 ${row.distance}マス`:`距離 ${row.distance} 格`);
  852 |     expect(await save(page)).toEqual(before.save,'Changing a quote/language must not pay or sample');
  853 |    }
  854 |   }
  855 |   await evidence(page,testInfo,'general-distance-'+row.distance+'-ja');
  856 |   await page.locator('#confirm-tactic').click();const after=await animation(page,{withView:false});
  857 |   expect(after.save.state.rng).toEqual(row.expected_rng);expect(after.save.state.battle.extended.tactical.points.attackers).toBe(before.save.state.battle.extended.tactical.points.attackers-4);
  858 |   expect(after.save.state.extension.events.items.at(-1).details.success).toBe(row.expected_success);
  859 |   expect(after.save.state.battle.extended.conditions?.units?.[String(row.target)]?.remaining??0).toBe(row.expected_success?3:0);
  860 |   expect(after.save.state.battle.attackers).toEqual(before.save.state.battle.attackers);expect(after.save.state.battle.defenders).toEqual(before.save.state.battle.defenders);
  861 |   await load(page,after.save,'committed-general-distance-'+row.distance+'.json');expect(await save(page)).toEqual(after.save);
  862 |   proof.push({distance:row.distance,threshold:row.percent,sample:row.sample,success:row.expected_success,rng:after.save.state.rng,roundtrip:true,preview_pure:true});
  863 |  }
  864 |  await attach(testInfo,'general-tactic-proof',proof);expect(pageErrors.get(page)).toEqual([]);
  865 | });
  866 | 
```