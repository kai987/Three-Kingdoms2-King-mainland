import original from '../../tools/browser-tests/playwright.config.mjs';
export default {...original, webServer:{...original.webServer,reuseExistingServer:true}, reporter:[['list']]};
