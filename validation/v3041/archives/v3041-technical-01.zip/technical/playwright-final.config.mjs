import original from '../../tools/browser-tests/playwright.config.mjs';
export default {...original, webServer:{...original.webServer, command:'node tests/browser_static_server.mjs build/web-final'}, reporter:[['list']]};
